namespace WikiQuizGenerator.Core.Exceptions;

public class RefreshTokenException(string message) : Exception(message);
﻿using FluentAssertions;
using WikiQuiz.Infrastructure;
using System.Collections.Immutable;

namespace WikiQuizGenerator.Pulumi.Azure.Tests;

/// <summary>
/// Unit tests for WikiQuiz Pulumi Azure infrastructure
/// These tests validate that the infrastructure components are configured correctly
/// without actually deploying to Azure
/// </summary>
public class InfrastructureTests
{
    /// <summary>
    /// Test that validates the StackConfig can be instantiated with valid configuration
    /// This ensures the configuration system can handle all necessary settings
    /// </summary>
    [Fact]
    public void StackConfig_ShouldInstantiateWithValidConfiguration()
    {
        // Arrange: Set up environment variables for configuration
        Environment.SetEnvironmentVariable("PULUMI_CONFIG_projectName", "WikiQuizGenerator");
        Environment.SetEnvironmentVariable("PULUMI_CONFIG_containerImage", "test-image:latest");
        Environment.SetEnvironmentVariable("PULUMI_CONFIG_postgresAdminLogin", "testadmin");
        Environment.SetEnvironmentVariable("PULUMI_CONFIG_postgresAdminPassword", "TestPassword123!");
        Environment.SetEnvironmentVariable("PULUMI_CONFIG_openAiApiKey", "test-openai-key");
        Environment.SetEnvironmentVariable("PULUMI_CONFIG_googleClientId", "test-google-client-id");
        Environment.SetEnvironmentVariable("PULUMI_CONFIG_googleClientSecret", "test-google-client-secret");
        Environment.SetEnvironmentVariable("PULUMI_CONFIG_jwtIssuer", "https://test-issuer.com");
        Environment.SetEnvironmentVariable("PULUMI_CONFIG_jwtAudience", "test-audience");
        Environment.SetEnvironmentVariable("PULUMI_CONFIG_jwtSecret", "test-jwt-secret");
        Environment.SetEnvironmentVariable("PULUMI_CONFIG_frontendUrl", "https://test-frontend.com");

        try
        {
            // Act: Create a StackConfig instance
            var config = new StackConfig();

            // Assert: Verify that configuration properties are accessible
            config.ProjectName.Should().Be("WikiQuizGenerator", "Project name should be loaded from configuration");
            config.ContainerImage.Should().Be("test-image:latest", "Container image should be loaded from configuration");
            config.PostgresAdminLogin.Should().Be("testadmin", "Postgres admin login should be loaded from configuration");
            config.JwtIssuer.Should().Be("https://test-issuer.com", "JWT issuer should be loaded from configuration");
            config.JwtAudience.Should().Be("test-audience", "JWT audience should be loaded from configuration");
            config.FrontendUrl.Should().Be("https://test-frontend.com", "Frontend URL should be loaded from configuration");
        }
        finally
        {
            // Cleanup: Remove environment variables
            Environment.SetEnvironmentVariable("PULUMI_CONFIG_projectName", null);
            Environment.SetEnvironmentVariable("PULUMI_CONFIG_containerImage", null);
            Environment.SetEnvironmentVariable("PULUMI_CONFIG_postgresAdminLogin", null);
            Environment.SetEnvironmentVariable("PULUMI_CONFIG_postgresAdminPassword", null);
            Environment.SetEnvironmentVariable("PULUMI_CONFIG_openAiApiKey", null);
            Environment.SetEnvironmentVariable("PULUMI_CONFIG_googleClientId", null);
            Environment.SetEnvironmentVariable("PULUMI_CONFIG_googleClientSecret", null);
            Environment.SetEnvironmentVariable("PULUMI_CONFIG_jwtIssuer", null);
            Environment.SetEnvironmentVariable("PULUMI_CONFIG_jwtAudience", null);
            Environment.SetEnvironmentVariable("PULUMI_CONFIG_jwtSecret", null);
            Environment.SetEnvironmentVariable("PULUMI_CONFIG_frontendUrl", null);
        }
    }
}

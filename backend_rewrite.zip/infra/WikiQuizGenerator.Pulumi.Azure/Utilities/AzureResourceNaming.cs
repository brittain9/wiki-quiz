using System;
using System.Text.RegularExpressions;

namespace WikiQuizGenerator.Pulumi.Azure.Utilities
{
    public static class AzureResourceNaming
    {
        private static string GenerateGuidSuffix(int length = 8)
        {
            return Guid.NewGuid().ToString("N").Substring(0, length);
        }

        public static string GenerateResourceGroupName(string projectName, string environment)
        {
            // Azure Resource Group: 1-90 chars. Common practice: lowercase alphanumeric, hyphens. Cannot end with '.'.
            string name = $"{projectName}-{environment}-rg".ToLowerInvariant();
            name = Regex.Replace(name, @"[^a-z0-9-]", "-"); // Replace invalid chars with hyphens
            name = Regex.Replace(name, @"-+", "-");          // Collapse consecutive hyphens
            name = name.Trim('-');                         // Trim leading/trailing hyphens

            if (string.IsNullOrWhiteSpace(name))
            {
                name = "default-rg-" + GenerateGuidSuffix(8);
            }

            if (name.Length > 90) name = name.Substring(0, 90);
            name = name.Trim('-'); // Trim again after truncation

            if (name.EndsWith(".")) name = name.Substring(0, name.Length - 1); // Ensure doesn't end with period

            if (string.IsNullOrWhiteSpace(name)) // Ensure not empty after all ops
            {
                 name = "rg-" + GenerateGuidSuffix(10); // Final fallback
            }
            return name;
        }

        public static string GenerateStorageAccountName(string projectName, string environment, string uniqueSuffix)
        {
            // Azure Storage Account: 3-24 chars. Lowercase letters and numbers only. (Globally unique)
            string name = $"sa{projectName}{environment}{uniqueSuffix}"; // Prefix 'sa' helps with type and min length
            name = Regex.Replace(name.ToLowerInvariant(), @"[^a-z0-9]", ""); // Lowercase and alphanumeric only

            if (name.Length > 24) name = name.Substring(0, 24);

            if (name.Length < 3) // Enforce min length
            {
                name = (name + GenerateGuidSuffix(3) + "000").Substring(0, 3);
            }
            return name;
        }

        public static string GenerateContainerRegistryName(string projectName, string environment, string uniqueSuffix)
        {
            // Azure Container Registry (ACR): 5-50 chars. Alphanumeric only. (Globally unique)
            string name = $"cr{projectName}{environment}{uniqueSuffix}"; // Prefix 'cr'
            name = Regex.Replace(name.ToLowerInvariant(), @"[^a-z0-9]", ""); // Lowercase and alphanumeric only

            if (name.Length > 50) name = name.Substring(0, 50);

            if (name.Length < 5) // Enforce min length
            {
                name = (name + GenerateGuidSuffix(5) + "00000").Substring(0, 5);
            }
            return name;
        }

        public static string GenerateKeyVaultName(string projectName, string environment, string uniqueSuffix)
        {
            // Azure Key Vault: 3-24 chars. Alphanumeric & hyphens. Starts with letter. Ends with letter/digit. No consecutive hyphens. (Globally unique)
            string name = $"kv-{projectName}-{environment}-{uniqueSuffix}".ToLowerInvariant();
            name = Regex.Replace(name, @"[^a-z0-9-]", "-"); // Allow only lowercase alphanumeric and hyphens
            name = Regex.Replace(name, @"-+", "-");          // Collapse consecutive hyphens

            if (!string.IsNullOrEmpty(name) && !char.IsLetter(name[0]))
            {
                name = "k" + name; // Ensure starts with a letter
                name = Regex.Replace(name, @"^k-+", "k-"); // Clean if "k-" + "-name" occurs
            }
            name = name.TrimStart('-'); // Trim any leading hyphen formed if original name was all invalid chars

            name = name.Trim('-'); // Trim leading/trailing hyphens

            if (string.IsNullOrWhiteSpace(name)) name = "kv-default-" + GenerateGuidSuffix(8);

            if (name.Length > 24) name = name.Substring(0, 24);
            name = name.TrimEnd('-'); // Ensure ends with letter/digit by removing trailing hyphen

            // Re-check start with letter after all operations, in case trimming/truncation affected it
            if (!string.IsNullOrEmpty(name) && !char.IsLetter(name[0]))
            {
                 name = "k" + (name.Length > 1 ? name.Substring(1) : "");
                 if (name.Length > 24) name = name.Substring(0, 24);
                 name = name.TrimEnd('-');
            }

            if (name.Length < 3 || string.IsNullOrWhiteSpace(name)) // Final check for min length and content
            {
                // Fallback to a compliant, unique name
                name = "kv-" + GenerateGuidSuffix(19); // e.g. kv- + 19_char_guid_segment = 22 chars
                if (!char.IsLetter(name[0])) name = "k" + name.Substring(1); // Ensure prefix starts with letter
                name = name.Substring(0, Math.Min(name.Length, 24)).TrimEnd('-');
                if (name.Length < 3) name = "kvvaliddefault"; // Absolute last resort
            }
            return name;
        }

        public static string GenerateSqlServerName(string projectName, string environment, string uniqueSuffix)
        {
            // Azure SQL Server: 1-63 chars. Lowercase letters, numbers, hyphens. Not start/end with hyphen. No consecutive hyphens. (Globally unique)
            string name = $"sql-{projectName}-{environment}-{uniqueSuffix}".ToLowerInvariant();
            name = Regex.Replace(name, @"[^a-z0-9-]", "-");
            name = Regex.Replace(name, @"-+", "-");
            name = name.Trim('-');

            if (string.IsNullOrWhiteSpace(name)) name = "sql-default-" + GenerateGuidSuffix(8);

            if (name.Length > 63) name = name.Substring(0, 63);
            name = name.Trim('-'); // Trim again after truncation

            if (string.IsNullOrWhiteSpace(name)) name = "sql-" + GenerateGuidSuffix(10); // Final fallback
            return name;
        }

        public static string GenerateSqlDatabaseName(string projectName, string environment)
        {
            // Azure SQL Database: 1-128 chars. We'll use lowercase alphanumeric & hyphens. Cannot end with '.'.
            string name = $"db-{projectName}-{environment}".ToLowerInvariant();
            name = Regex.Replace(name, @"[^a-z0-9-]", "-");
            name = Regex.Replace(name, @"-+", "-");
            name = name.Trim('-');

            if (string.IsNullOrWhiteSpace(name)) name = "db-default-" + GenerateGuidSuffix(8);

            if (name.Length > 128) name = name.Substring(0, 128);
            name = name.TrimEnd('-', '.'); // Trim trailing hyphens or periods

            if (string.IsNullOrWhiteSpace(name)) name = "db-" + GenerateGuidSuffix(10);
            return name;
        }

        public static string GenerateAppConfigurationName(string projectName, string environment, string uniqueSuffix)
        {
            // Azure App Configuration: 5-50 chars. Alphanumeric & hyphens. Start/end with letter/number. (Globally unique)
            string name = $"ac-{projectName}-{environment}-{uniqueSuffix}".ToLowerInvariant();
            name = Regex.Replace(name, @"[^a-z0-9-]", "-");
            name = Regex.Replace(name, @"-+", "-");
            name = name.Trim('-');

            if (string.IsNullOrWhiteSpace(name)) name = "ac-default-" + GenerateGuidSuffix(8);

            // Ensure starts with letter/number after initial prefix and trimming
            if(!string.IsNullOrEmpty(name) && !char.IsLetterOrDigit(name[0]))
            {
                name = "a" + name; // Prepend 'a'
                name = Regex.Replace(name, @"^a-+", "a-");
                name = name.TrimStart('-');
            }

            if (name.Length > 50) name = name.Substring(0, 50);
            name = name.Trim('-'); // Ensure ends with letter/number by removing trailing hyphen

            if (name.Length < 5 || string.IsNullOrWhiteSpace(name))
            {
                 name = "ac-" + GenerateGuidSuffix(10) + "val"; // Fallback, ensure end alphanumeric
                 if (name.Length > 50) name = name.Substring(0, 50);
                 name = name.TrimEnd('-');
                 if (name.Length < 5) name = (name + "00000").Substring(0,5);
            }

            // Final check for start/end alphanumeric
            if (!string.IsNullOrWhiteSpace(name))
            {
                if (!char.IsLetterOrDigit(name[0]) || !char.IsLetterOrDigit(name[name.Length - 1]))
                {
                    name = "appconfig" + GenerateGuidSuffix(10); // A very safe fallback
                    if (name.Length > 50) name = name.Substring(0, 50);
                }
            }
            else // If name became null or whitespace through the process
            {
                 name = "appcf" + GenerateGuidSuffix(10); // Safe fallback
                 if (name.Length > 50) name = name.Substring(0, 50);
            }
            return name;
        }

        public static string GenerateContainerAppName(string projectName, string environment)
        {
            // Azure Container App: 2-32 chars. Lowercase letters, numbers, hyphens. Not start/end with hyphen.
            string name = $"ca-{projectName}-{environment}".ToLowerInvariant();
            name = Regex.Replace(name, @"[^a-z0-9-]", "-");
            name = Regex.Replace(name, @"-+", "-");
            name = name.Trim('-');

            if (string.IsNullOrWhiteSpace(name)) name = "ca-default-" + GenerateGuidSuffix(6);

            if (name.Length > 32) name = name.Substring(0, 32);
            name = name.Trim('-'); // Trim again after truncation

            if (name.Length < 2 || string.IsNullOrWhiteSpace(name))
            {
                 name = "ca-" + GenerateGuidSuffix(8); // Final fallback
                 if (name.Length > 32) name = name.Substring(0, 32);
                 name = name.Trim('-');
                 if (name.Length < 2) name = (name + "00").Substring(0,2);
            }
            return name;
        }

        public static string GenerateContainerAppsEnvironmentName(string projectName, string environment)
        {
            // Azure Container Apps Environment: 2-32 chars. Lowercase letters, numbers, hyphens. Not start/end with hyphen.
            string name = $"cae-{projectName}-{environment}".ToLowerInvariant();
            name = Regex.Replace(name, @"[^a-z0-9-]", "-");
            name = Regex.Replace(name, @"-+", "-");
            name = name.Trim('-');

            if (string.IsNullOrWhiteSpace(name)) name = "cae-default-" + GenerateGuidSuffix(5);

            if (name.Length > 32) name = name.Substring(0, 32);
            name = name.Trim('-'); // Trim again

            if (name.Length < 2 || string.IsNullOrWhiteSpace(name))
            {
                name = "cae-" + GenerateGuidSuffix(8); // Final fallback
                if (name.Length > 32) name = name.Substring(0, 32);
                name = name.Trim('-');
                if (name.Length < 2) name = (name + "00").Substring(0,2);
            }
            return name;
        }
    }
}
﻿namespace WikiQuizGenerator.Core.Models
{
    public class ErrorModel
    {
        public string Message { get; set; }
        public int StatusCode { get; set; }
        public string ErrorType { get; set; }
    }
}

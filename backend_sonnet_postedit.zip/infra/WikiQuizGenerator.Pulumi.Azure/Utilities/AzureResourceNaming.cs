using System;
using System.Text.RegularExpressions;

namespace WikiQuizGenerator.Pulumi.Azure.Utilities
{
    public static class AzureResourceNaming
    {
        public static string GenerateResourceGroupName(string projectName, string environment)
        {
            // Resource group names can include alphanumerics, underscores, parentheses, hyphens, periods, and can be up to 90 characters
            return $"rg-{projectName.ToLower()}-{environment.ToLower()}";
        }

        public static string GenerateStorageAccountName(string projectName, string environment, string uniqueSuffix)
        {
            // Storage account names must be between 3 and 24 characters, lowercase letters and numbers only
            var name = $"st{CleanName(projectName)}{CleanName(environment)}{uniqueSuffix}";
            return name.ToLower().Substring(0, Math.Min(name.Length, 24));
        }

        public static string GenerateContainerRegistryName(string projectName, string environment, string uniqueSuffix)
        {
            // ACR names must be between 5 and 50 characters, alphanumerics only
            var name = $"cr{CleanName(projectName)}{CleanName(environment)}{uniqueSuffix}";
            return name.ToLower().Substring(0, Math.Min(name.Length, 50));
        }

        public static string GenerateKeyVaultName(string projectName, string environment, string uniqueSuffix)
        {
            // Key Vault names must be between 3 and 24 characters, alphanumerics and hyphens, start with letter, end with letter or digit
            var name = $"kv-{CleanName(projectName)}-{CleanName(environment)}-{uniqueSuffix}";
            return name.ToLower().Substring(0, Math.Min(name.Length, 24));
        }

        public static string GenerateSqlServerName(string projectName, string environment, string uniqueSuffix)
        {
            // SQL Server names must be between 1 and 63 characters, lowercase letters, numbers, and hyphens only
            var name = $"sql-{CleanName(projectName)}-{CleanName(environment)}-{uniqueSuffix}";
            return name.ToLower().Substring(0, Math.Min(name.Length, 63));
        }

        public static string GenerateSqlDatabaseName(string projectName, string environment)
        {
            // SQL Database names can be up to 128 characters, cannot end with period
            var name = $"sqldb-{CleanName(projectName)}-{CleanName(environment)}";
            return name.ToLower();
        }

        public static string GenerateAppConfigurationName(string projectName, string environment, string uniqueSuffix)
        {
            // App Configuration names must be between 5 and 50 characters, alphanumerics and hyphens
            var name = $"appcs-{CleanName(projectName)}-{CleanName(environment)}-{uniqueSuffix}";
            return name.ToLower().Substring(0, Math.Min(name.Length, 50));
        }

        public static string GenerateContainerAppName(string projectName, string environment)
        {
            // Container App names must be between 2 and 32 characters, alphanumerics and hyphens
            var name = $"ca-{CleanName(projectName)}-{CleanName(environment)}";
            return name.ToLower().Substring(0, Math.Min(name.Length, 32));
        }

        public static string GenerateContainerAppsEnvironmentName(string projectName, string environment)
        {
            // Container Apps Environment names must be between 2 and 64 characters, alphanumerics and hyphens
            var name = $"cae-{CleanName(projectName)}-{CleanName(environment)}";
            return name.ToLower().Substring(0, Math.Min(name.Length, 64));
        }

        // Helper method to clean names by removing special characters and spaces
        private static string CleanName(string name)
        {
            // Remove special characters and spaces, replace with empty string
            return Regex.Replace(name, "[^a-zA-Z0-9]", "");
        }
    }
}